document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('task-form');
    const taskSummaryBody = document.getElementById('task-summary-body');

    // Fetch existing tasks and display them
    fetchTasks();

    // Handle form submission
    taskForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        
        const taskName = document.getElementById('taskName').value;
        const timeSpent = document.getElementById('timeSpent').value;

        const task = {
            taskName,
            timeSpent: parseFloat(timeSpent)
        };

        try {
            const response = await fetch('http://localhost:3001/tasks', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(task)
            });

            if (response.ok) {
                const newTask = await response.json();
                addTaskToTable(newTask);
                taskForm.reset();
            } else {
                console.error('Error adding task:', response.statusText);
            }
        } catch (error) {
            console.error('Error adding task:', error);
        }
    });

    async function fetchTasks() {
        try {
            const response = await fetch('http://localhost:3001/tasks');
            const tasks = await response.json();
            tasks.forEach(task => addTaskToTable(task));
        } catch (error) {
            console.error('Error fetching tasks:', error);
        }
    }

    function addTaskToTable(task) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${task.taskName}</td>
            <td>${task.timeSpent}</td>
            <td>${new Date(task.date).toLocaleDateString()}</td>
        `;
        taskSummaryBody.appendChild(row);
    }
});
